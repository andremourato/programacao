Pacman

Desenvolvido por:
- Andr� Ribeiro Martins Marques Mourato/ N� Mec: 84745
- Jos� Diogo Xavier Monteiro/ N�Mec: 84736

Instru��es:

Esta vers�o do jogo pacman consiste numa altera��o do jogo original, introduzindo algumas habilidades especiais.

Objetivo

O objetivo deste jogo � comer todas as bolas brancas, sem colidir com os fantasmas. Esta tarefa � facilitada com o uso de bolas especiais que atribuem certas habilidades ao pacman.

Habilidades:

Invert: � ativada quando o pacman passa nas bolas vermelhas. Inverte a trajet�ria do fantasma vermelho e azul, e torna o cen�rio vermelho.
SpeedUp: � ativada quando o pacman come a bola verde. O pacman ganha super velocidade, tal como os fantasmas.
Godmode: � ativada quando o pacman come a bola roxa. O pacman torna-se invulner�vel temporariamente, podendo atravessar fantasmas enquanto estiver sob o efeito da bola roxa.

Controlos:

Seta para cima: Pacman move-se para cima;
Seta para baixo: Pacman move-se para baixo;
Seta para a direita: Pacman move-se para a direita;
Seta para a esquerda: Pacman move-se para a esquerda;
Tecla 'm': Ligar/Desligar o som;
Tecla 'Spacebar': Colocar o jogo em pausa;

Creditos:

Todos os sons, a imagem de fundo do menu inicial e os tipos de letra utilizados, foram retirados do site: http://www.classicgaming.cc/classics/pac-man/